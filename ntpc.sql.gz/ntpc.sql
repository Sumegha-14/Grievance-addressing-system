-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 13, 2019 at 08:37 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ntpc`
--

-- --------------------------------------------------------

--
-- Table structure for table `emp_save`
--

CREATE TABLE `emp_save` (
  `emp_no` int(10) NOT NULL,
  `request_id` int(10) NOT NULL,
  `request` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `remarks` varchar(200) NOT NULL,
  `date` date NOT NULL,
  `t_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp_save`
--

INSERT INTO `emp_save` (`emp_no`, `request_id`, `request`, `description`, `remarks`, `date`, `t_date`) VALUES
(1100, 30, 'abcd', 'mnbv', 'ok', '2019-06-13', '0000-00-00'),
(1100, 31, 'abcd', 'mnbv', 'ok', '2019-06-13', '0000-00-00'),
(1100, 32, 'abcd', 'mnbv', 'ok', '2019-06-13', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `emp_no` int(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `emp_name` varchar(15) NOT NULL,
  `dept_name` varchar(15) NOT NULL,
  `enable` char(1) NOT NULL,
  `access` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`emp_no`, `password`, `emp_name`, `dept_name`, `enable`, `access`) VALUES
(1000, '1', 'Tani', 'cse', 'y', 1),
(1001, '1', 'q', 'w', 'y', 3),
(1100, '1', 'abcd', 'mtc', 'y', 1),
(1101, '1', 'xyz', 'safety', 'y', 2),
(1103, '1', 't', 'j', 'y', 3),
(1104, '1', 'qwerty', 'poiu', 'y', 4);

-- --------------------------------------------------------

--
-- Table structure for table `protection`
--

CREATE TABLE `protection` (
  `emp_no` int(10) NOT NULL,
  `request_id` int(10) NOT NULL,
  `request` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `remark_1` varchar(200) NOT NULL,
  `remark_2` varchar(200) NOT NULL,
  `remark_3` varchar(200) NOT NULL,
  `remark_4` varchar(200) NOT NULL,
  `status` int(2) NOT NULL,
  `date` date NOT NULL,
  `Unit` int(2) NOT NULL,
  `Bypassdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `protection`
--

INSERT INTO `protection` (`emp_no`, `request_id`, `request`, `description`, `remark_1`, `remark_2`, `remark_3`, `remark_4`, `status`, `date`, `Unit`, `Bypassdate`) VALUES
(1100, 34, 'abcd', 'mnbv', 'ok', '', '', '', 5, '2019-06-10', 1, '0000-00-00'),
(1100, 35, 'fgbh', 'grfed', 'ok', '', '', '', 5, '2019-06-10', 0, '0000-00-00'),
(1100, 36, 'abcdu', 'cefef', 'fref', '', '', '', 5, '2019-06-11', 0, '0000-00-00'),
(1000, 37, 'abcd', 'grfed', 'rf', '', '', '', 3, '2019-06-11', 0, '0000-00-00'),
(1100, 41, 'asdfg', 'ok', 'ok', '', '', '', 5, '2019-06-11', 0, '0000-00-00'),
(1000, 42, 'qwertyu', 'asdfg', 'okiiii', '', '', '', 2, '2019-06-11', 0, '0000-00-00'),
(1000, 43, 'abcdefghij', 'zxcvb', 'we', '', '', '', 4, '2019-05-11', 0, '2019-06-13'),
(1100, 44, 'ancdf', 'ok', 'kaiy', '', '', '', 0, '2019-05-11', 0, '0000-00-00'),
(1100, 45, 'new', 'saved1', 'okay', '', '', '', 5, '2019-05-11', 0, '0000-00-00'),
(1100, 46, 'new', 'saved2', 'OkAy', '', '', '', 0, '2019-05-11', 0, '0000-00-00'),
(1100, 47, 'new added', 'something', 'okaie', '', '', '', 5, '2019-06-12', 0, '0000-00-00'),
(1100, 48, 'fgbh', 'mnbv', 'kaiy', '', '', '', 0, '2019-05-13', 0, '0000-00-00'),
(1100, 49, 'abcde', 'grfed', 'rf', '', '', '', 0, '2019-05-13', 0, '0000-00-00'),
(1100, 50, 'new', 'okk', 'ok', '', '', '', 0, '2019-05-13', 0, '0000-00-00'),
(1100, 51, 'abcd', 'mnbv', 'fref', '', '', '', 0, '2019-05-13', 0, '0000-00-00'),
(1100, 54, 'request', 'onne', 'ok', '', '', '', 4, '2019-05-13', 0, '2019-06-13');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `emp_save`
--
ALTER TABLE `emp_save`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`emp_no`);

--
-- Indexes for table `protection`
--
ALTER TABLE `protection`
  ADD PRIMARY KEY (`request_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `emp_save`
--
ALTER TABLE `emp_save`
  MODIFY `request_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `protection`
--
ALTER TABLE `protection`
  MODIFY `request_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
